const { initializeWhatsApp } = require('./whatsapp/client');
const { setupMessageHandlers } = require('./handlers/messageHandler');

async function startBot() {
  try {
    const client = await initializeWhatsApp();
    setupMessageHandlers(client);
  } catch (error) {
    console.error('Error starting the bot:', error);
    process.exit(1);
  }
}

startBot();