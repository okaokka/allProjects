const { handleCommand } = require('./commandHandler');

function setupMessageHandlers(client) {
  client.on('message', async (message) => {
    try {
      // Ignore messages from groups
      if (message.isGroup) return;

      const text = message.body.toLowerCase();

      // Handle commands (messages starting with !)
      if (text.startsWith('!')) {
        await handleCommand(message);
        return;
      }

      // Handle regular messages
      await message.reply('👋 Hello! I am a WhatsApp bot. Use !help to see available commands.');
    } catch (error) {
      console.error('Error handling message:', error);
      message.reply('Sorry, there was an error processing your message.');
    }
  });
}

module.exports = { setupMessageHandlers };