async function handleCommand(message) {
  const command = message.body.toLowerCase().split(' ')[0];

  switch (command) {
    case '!help':
      await message.reply(
        '🤖 Available Commands:\n\n' +
        '!help - Show this help message\n' +
        '!ping - Check if bot is active\n' +
        '!time - Get current time\n' +
        '!echo [message] - Echo back your message'
      );
      break;

    case '!ping':
      await message.reply('🏓 Pong!');
      break;

    case '!time':
      const now = new Date().toLocaleString();
      await message.reply(`🕒 Current time: ${now}`);
      break;

    case '!echo':
      const echoMessage = message.body.slice(6).trim();
      if (echoMessage) {
        await message.reply(`🔄 ${echoMessage}`);
      } else {
        await message.reply('Please provide a message to echo!');
      }
      break;

    default:
      await message.reply('❌ Unknown command. Use !help to see available commands.');
  }
}

module.exports = { handleCommand };