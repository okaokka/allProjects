const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

function initializeWhatsApp() {
  return new Promise((resolve, reject) => {
    // Create a new WhatsApp client
    const client = new Client({
      authStrategy: new LocalAuth(),
      puppeteer: {
        args: ['--no-sandbox']
      }
    });

    // Generate QR code for authentication
    client.on('qr', (qr) => {
      console.log('Scan this QR code with your WhatsApp:');
      qrcode.generate(qr, { small: true });
    });

    // Handle client ready event
    client.on('ready', () => {
      console.log('WhatsApp client is ready!');
      resolve(client);
    });

    // Handle authentication failure
    client.on('auth_failure', (error) => {
      console.error('Authentication failed:', error);
      reject(error);
    });

    // Initialize the client
    client.initialize().catch(reject);
  });
}

module.exports = { initializeWhatsApp };